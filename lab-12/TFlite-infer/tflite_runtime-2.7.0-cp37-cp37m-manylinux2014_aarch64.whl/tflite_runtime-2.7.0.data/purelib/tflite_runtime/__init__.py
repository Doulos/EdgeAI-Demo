__version__ = '2.7.0'
__git_version__ = '0.6.0-118185-g520eb3b'
